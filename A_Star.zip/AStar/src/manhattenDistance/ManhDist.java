/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package manhattenDistance;

/**
 * Class ManhDist describes the distance of a set of coordinates to another set
 * of coordinates as Manhatten Distance.
 *
 * @author flo
 */
public class ManhDist {

  private int targetX, targetY;
  private int positionX, positionY;
  private double distance;
  private boolean wasOpend;
  private boolean wasTouched;
  private boolean isTarget;
  private boolean isStart;


  public ManhDist(int targetX, int targetY, int positionX, int positionY) {
    this.targetX = targetX;
    this.targetY = targetY;
    this.positionX = positionX;
    this.positionY = positionY;
    
    if (targetX == positionX && targetY == positionY)
      this.isTarget = true; // Starting "node" is already open
    else
      this.isTarget = false;
    this.wasTouched = false;  
    this.wasOpend = false;
    getDistance(); // NetBeans Warning/Hint Overridable Method called in Constr.
  }

  public boolean isIsStart() {
    return isStart;
  }

  public void setIsStart(boolean isStart) {
    this.isStart = isStart;
  }
  public void setWasTouched(boolean wasTouched) {
    this.wasTouched = wasTouched;
  }

  public boolean isWasTouched() {
    return wasTouched;
  }

  public void setWasOpend(boolean wasOpend) {
    this.wasOpend = wasOpend;
  }

  public boolean isWasOpend() {
    return wasOpend;
  }

  public boolean isIsTarget() {
    return isTarget;
  }

  public int getPositionX() {
    return positionX;
  }

  public int getPositionY() {
    return positionY;
  }

  public double getDistance() {
    distance = Math.sqrt((targetX - positionX) * (targetX - positionX) +
         (targetY - positionY) * (targetY - positionY));
    return distance;
}

  @Override
  public String toString() {
    return "ManhDist{" + "targetX=" + targetX + ", targetY=" + targetY + 
         ", positionX=" + positionX + ", positionY=" + positionY +
         ", distance=" + distance + '}';
  }
  
  public boolean equals(ManhDist dist){
    if (this.positionX == dist.positionX && this.positionY == dist.positionY)
      return true;
    return false;
  }
}
