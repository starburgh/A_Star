/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package manhattenDistance;

/**
 * This main-Class tests the ManhMap and ManhDist Classes.
 *
 * @author flo
 */
public class TestManhDist {

  public static void main(String[] args) {
    ManhMap manhMap = new ManhMap(10, 10, 4, 1, 8, 8);
    // get implemented in constructor manhMap.populate();
    do{
      System.out.println(manhMap.getPositionX() + " " + manhMap.getPositionY());
      manhMap.draw();
      manhMap.move();
    } while (manhMap.getPositionX() != manhMap.getTargetX()
         || manhMap.getPositionY() != manhMap.getTargetY()); 
    manhMap.draw();
  }
}
