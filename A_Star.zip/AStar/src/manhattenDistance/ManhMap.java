/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package manhattenDistance;

/**
 * This Class describes 2D-Arrays which hold ManhDist Objects.
 * @author flo
 */
public class ManhMap{
  public static final String ANSI_RESET = "\u001B[0m"; 
  public static final String ANSI_RED = "\u001B[31m"; 
  public static final String ANSI_GREEN = "\u001B[32m";
  public static final String ANSI_YELLOW = "\u001B[33m";
  public static final String ANSI_BLUE = "\u001B[34m";
  public static final String ANSI_PURPLE = "\u001B[35m"; 
  public static final String ANSI_CYAN = "\u001B[36m"; 
  private int sizeX, sizeY;
  private ManhDist[][] map;
  private int targetX, targetY;
  private int positionX, positionY; 
  private ManhDist position;

  public ManhMap(int sizeX, int sizeY) {
    this.sizeX = sizeX;
    this.sizeY = sizeY;
    map = new ManhDist[sizeX][sizeY];
  }

  public ManhMap(int sizeX, int sizeY, int targetX, int targetY, int positionX, int positionY){
    this(sizeX, sizeY);
    this.targetX = targetX;
    this.targetY = targetY;
    this.positionX = positionX;
    this.positionY = positionY;
    populate(); // Overidable Method called in constructor
    this.position = map[this.positionX][this.positionY]; 
  }

  public int getTargetX() {
    return targetX;
  }

  public int getTargetY() {
    return targetY;
  }

  public int getPositionX() {
    return positionX;
  }

  public int getPositionY() {
    return positionY;
  }

  public void populate(){
    for (int x = 0; x < map.length; x++){
      for (int y = 0; y < map[x].length; y++)
        map[x][y] = new ManhDist(targetX, targetY, x, y);
    }
    map[positionX][positionY].setIsStart(true);
  }
  public void draw(){
    for(ManhDist mMap[]: map){
      for(ManhDist mDist: mMap){
        if (mDist.equals(position))
          System.out.printf("%s%05.2f%s ", ANSI_RED, mDist.getDistance(), ANSI_RESET);
        else if (mDist.isIsStart())
          System.out.printf("%s%05.2f%s ", ANSI_BLUE, mDist.getDistance(), ANSI_RESET);
        else if (mDist.isWasOpend())
          System.out.printf("%s%05.2f%s ", ANSI_CYAN, mDist.getDistance(), ANSI_RESET);
        else if (mDist.isIsTarget())
          System.out.printf("%s%05.2f%s ", ANSI_GREEN, mDist.getDistance(), ANSI_RESET);
        else
          System.out.printf("%05.2f " ,mDist.getDistance());
      }
      System.out.println("");
    }
    System.out.println("");
  }
  public void move(){
    double minDist = Double.POSITIVE_INFINITY;
    int minX = 0, minY = 0;
    for (int x = position.getPositionX() - 1; x <= position.getPositionX() + 1; x++){
      if (map.length <= x || 0 > x)
        continue;
      for (int y = position.getPositionY() - 1; y <= position.getPositionY() + 1; y++){
        if (map[x].length <= y || 0 > y)
          continue;
        if ( map[x][y].equals(position))
          continue;
        if (map[x][y].getDistance() < minDist){
          minX = x;
          minY = y;
          minDist = map[x][y].getDistance();
        }
      }
    }
    positionX = minX;
    positionY = minY;
    position = map[minX][minY];
    map[minX][minY].setWasOpend(true);
  }
    
  public void errmove(){
    double min = Double.POSITIVE_INFINITY;
    int minX, minY;
    for (ManhDist[] rows: map){
      for (ManhDist field: rows){
        if (field.getDistance() < min && !field.equals(position)){
          minX = field.getPositionX();
          minY = field.getPositionY();
          min = field.getDistance();
        }
      }
    }
  }
}
